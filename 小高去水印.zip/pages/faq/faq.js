Page({
    data: {},
    onLoad: function(a) {
        console.log(a.arg);
        this.setData({
            status: a.arg
        });
    }
});