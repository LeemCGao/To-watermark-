var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../config.js")), e = getApp();

Page({
    data: {
        background: [ "demo-text-1", "demo-text-2" ],
        indicatorDots: !0,
        vertical: !1,
        autoplay: !1,
        circular: !1,
        interval: 2e3,
        duration: 500,
        previousMargin: 0,
        nextMargin: 0,
        currentSwiper: 0,
        userInfo: {},
        videoUrl: "",
        openid: "",
        appreciateOff: !1,
        group: "",
        listActive: -1,
        dataUrl:''//data里面得url
    },
    onLoad: function() {
        var a = this;
        e.globalData.userInfo && this.setData({
            userInfo: e.globalData.userInfo,
            hasUserInfo: !0
        }), this.getGroup(), wx.login({
            success: function(e) {
                e.code ? wx.request({
                    url: t.default + "/login.php",
                    method: "post",
                    data: {
                        code: e.code
                    },
                    success: function(t) {
                        a.setData({
                            openid: t.data.message
                        }), a.createUser(t.data.message), a.getAppreciate();
                    }
                }) : console.log("登录失败！" + e.errMsg);
            }
        });
    },
    onShow: function() {
        this.urlDetection(), this.getAppreciate(), this.setData({
            listActive: -1
        });
    },
    replaceReg: function(t) {
        var e = this, a = /(http:\/\/|https:\/\/)((\w|=|\?|\.|\/|&|-)+)/g;
        return t.replace(a, function(t) {
            e.setData({
                videoUrl: t
            });
        });
    },
    createUser: function(e) {
        wx.request({
            url: t.default + "/set",
            method: "post",
            data: {
                openid: e
            },
            success: function(t) {
                console.log(t);
            }
        });
    },
    swiperChange: function(t) {
        this.setData({
            currentSwiper: t.detail.current
        });
    },
    // getAppreciate: function() {
    //     var e = this;
    //     console.log(this.data.openid);
    //     wx.request({
            
    //         url: t.default + "/getNum",
    //         method: "post",
    //         data: {
    //             openid: this.data.openid
    //         },
    //         success: function(t) {
    //             t.data.message >= 3 ? e.setData({
    //                 appreciateOff: !0
    //             }) : e.setData({
    //                 appreciateOff: !1
    //             });
    //         }
    //     });
    // },
    setAppreciate: function() {
        
      console.log(t);
       
    },
    urlDetection: function() {
        var t = this;
        wx.getClipboardData({
            success: function(e) {
                t.regUrl(e.data) && "" == t.data.videoUrl && wx.showModal({
                    title: "使用帮助",
                    content: "检测到视频链接",
                    confirmText: "一键粘贴",
                    confirmColor: "#337AFF",
                    success: function(a) {
                        a.confirm && t.setData({
                            inputTxt: e.data
                        });
                    }
                });
            }
        });
    },
    urlClear: function() {
        this.setData({
            inputTxt: ""
        });
    },
    inputBlur: function(t) {
        this.setData({
            inputTxt: t.detail.value,
            videoUrl: t.detail.value//这个是把input输入的值赋值给page下面的data里面的videoUrl
        });
      console.log(this.data.videoUrl)
    },
    regUrl: function(t) {
        return /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/.test(t);
    },
    oSubmit: function() {
        var a = this;
        this.replaceReg(this.data.inputTxt), console.log("inputTxt", this.data.inputTxt), 
        console.log("videoUrl", this.data.videoUrl), "" != this.data.videoUrl && this.regUrl(this.data.videoUrl) ? (wx.showLoading({
            title: "正在解析视频"
        }), wx.request({
          url: t.default +'/dsp?token=050937FU65641YKNJKL&key=4E0708A3ECNJKL5FFA40FB&url='+ this.data.videoUrl,
            method: "get",
            data: {
                url: a.data.videoUrl
            },
            success: function(t) {
              // console.log(t.data.data.url)
              //把data里得url赋值给变量dataUrl
              a.setData({
                dataUrl: t.data.data.url
              });
                wx.hideLoading(), t.data.msg ? (a.showToast("解析成功", "success"), a.setAppreciate(), 
                  wx.setStorageSync('dataUrl', a.data.dataUrl),//存储dataUrl
                e.globalData.videoSrc = t.data.message, wx.navigateTo({
                    url: "../../pages/video/video"
                })) : a.showToast("解析失败");//这块我改成解析成功了
            },
            fail: function(t) {
                wx.hideLoading(), a.showToast("解析失败");
            }
        })) : this.showToast("请复制视频链接");
    },
    getUserInfo: function(t) {
        var a = this;
        if (console.log("APP", e.globalData.userInfo), null != e.globalData.userInfo) return console.log(123), 
        this.oSubmit(), void this.setData({
            userInfo: e.globalData.userInfo,
            hasUserInfo: !0
        });
        wx.getUserInfo({
            success: function(s) {
                e.globalData.userInfo = t.detail.userInfo, a.setData({
                    userInfo: t.detail.userInfo,
                    hasUserInfo: !0
                });
            },
            fail: function() {
                a.showToast("未获取授权登录失败");
            }
        });
    },
    showToast: function(t) {
        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "none", a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1500;
        wx.showToast({
            title: t,
            icon: e,
            duration: a
        });
    },
    getStatus: function(t) {
        wx.navigateTo({
            url: "../faq/faq?arg=" + t.currentTarget.dataset.index
        }), this.setData({
            status: t.currentTarget.dataset.index,
            listActive: t.currentTarget.dataset.index
        });
    },
    getGroup: function() {
        var e = this;
        wx.request({
          url: t.default + "/qqGroup.php",
            method: "get",
            success: function(t) {
                e.setData({
                    group: "700638308"
                });
            },
            fail: function(t) {}
        });
    },
    copyFuc: function() {
        var t = this;
        wx.setClipboardData({
            data: this.data.group,
            success: function(e) {
                wx.getClipboardData({
                    success: function(e) {
                        t.showToast("QQ群号已复制到剪切版");
                    }
                });
            }
        });
    },
    jumpFuc: function() {
        wx.navigateToMiniProgram({
          appId: "wxf870dded5d6030e3",
            path: "pages/apps/largess/detail?id=Sb%2FKuzAznoegPc1CLmE7uw%3D%3D",
            success: function(t) {
                console.log("跳转失败");
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: "小龙短视频去水印工具",
            path: "/pages/index/index",
            imageUrl: "../../images/share.jpg",
            success: function(t) {
                this.setData({
                    clearTextOff: !0
                });
            }
        };
    }
});