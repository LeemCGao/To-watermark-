var o = getApp();

Page({
    data: {
        motto: "Hello World",
        userInfo: {},
        hasUserInfo: !1,
        canIUse: wx.canIUse("button.open-type.getUserInfo")
    },
    onShow: function() {
        o.globalData.userInfo && (console.log("已经", o.globalData.userInfo), this.setData({
            userInfo: o.globalData.userInfo,
            hasUserInfo: !0
        }));
    },
    getUserInfo: function(s) {
        var t = this;
        wx.getUserInfo({
            success: function(a) {
                console.log(a), o.globalData.userInfo = s.detail.userInfo, t.setData({
                    userInfo: s.detail.userInfo,
                    hasUserInfo: !0
                });
            },
            fail: function() {
                t.showToast("未获取授权登录失败");
            }
        });
    },
    showToast: function(o) {
        wx.showToast({
            title: o,
            icon: "none"
        });
    },
    getStatus: function() {
        wx.navigateTo({
            url: "../faq/faq"
        });
    },
    getPermissions: function() {
        var s = this;
        o.globalData.userInfo ? wx.openSetting({
            success: function(t) {
                t.authSetting["scope.userInfo"] || (o.globalData.userInfo = null, s.setData({
                    userInfo: o.globalData.userInfo,
                    hasUserInfo: !s.data.hasUserInfo
                }));
            }
        }) : wx.navigateTo({
            url: "../set/set"
        });
    }
});